Sim Companion
Version: 1.0.0 (Alpha)


------------------------------
	 Disclaimer
------------------------------
I did not create vJoy, credit goes to the original author and contributers.

vJoy might cause issues in some games (likely due to games having bad controller support).
If you encounter such issues, I recommend uninstalling vJoy while playing such games.


------------------------------
	Prerequisite
------------------------------
vJoy is an open-source driver software that is needed for Sim Companion to work.

Download and install vJoy from:
- https://sourceforge.net/projects/vjoystick/files/latest/download

It is highly recommended to configure vJoy and change the Number of Buttons to 128.


------------------------------
	Installation
------------------------------
Ensure you've installed vJoy from the above "Prerequisite" section.

No installation is required for Sim Companion itself, just extract the zip file 
and run the executable.

Install the Sim Companion app on your Android device from:
- https://play.google.com/store/apps/details?id=com.atompunkapps.simcompanion


------------------------------
	 How to use
------------------------------
Ensure your PC and Android device are on the same network/WiFi.

Ensure Sim Companion is allowed through Windows Firewall on your PC.

Run both Windows and Android applications and they should find each other.


------------------------------
	    Notes
------------------------------
Windows might show a big and scary window saying "Windows protected your PC" for 
the first time you run the application;

I cannot afford the ridiculous $(400 - 700)/year cost for a digital certificate.

Just click on 'More info' and 'Run anyway'

If you're still concerned about security, you can take a look at the source and/or 
build the Windows application yourself.




Need any help or have suggestions? Email me at:
- atompunkapps@gmail.com

Thank you!  :)
